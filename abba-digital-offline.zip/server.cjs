var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_genai = require("@google/genai");
import_dotenv.default.config();
var geminiApiKey = process.env.GEMINI_API_KEY || "";
var ai = geminiApiKey ? new import_genai.GoogleGenAI({ apiKey: geminiApiKey }) : null;
async function validateWithGemini(payload) {
  if (!ai) {
    console.warn("GEMINI_API_KEY is not defined. Skipping spam validation.");
    return { isValid: true };
  }
  const { firstName, lastName, message, phone } = payload;
  const prompt = `Voc\xEA \xE9 um filtro de seguran\xE7a inteligente anti-spam e de modera\xE7\xE3o para o site "ABBA DIGITAL" (\xC1baco Brasileiro de Alfabetiza\xE7\xE3o Bil\xEDngue).
Analise os seguintes dados enviados no formul\xE1rio de contato por um usu\xE1rio:
Nome: ${firstName}
Sobrenome: ${lastName}
Mensagem: ${message}
${phone ? `WhatsApp/Telefone: ${phone}` : ""}

Classifique se o envio \xE9 spam (propagandas de produtos/servi\xE7os, links maliciosos, textos em idiomas aleat\xF3rios sem rela\xE7\xE3o com o projeto, tentativas de invas\xE3o, caracteres aleat\xF3rios, ou mensagens ofensivas/inadequadas) ou se \xE9 uma mensagem de contato leg\xEDtima (perguntas sobre o projeto, elogios, interesse em parcerias, suporte, etc.).

Responda estritamente no formato JSON abaixo:
{
  "isValid": true ou false (false se for spam/inadequado, true se for leg\xEDtimo),
  "reason": "Se for inv\xE1lido/spam, explique brevemente o motivo em portugu\xEAs. Se for v\xE1lido, deixe vazio."
}`;
  const maxRetries = 3;
  let delay = 500;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const apiCall = ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });
      const timeoutPromise = new Promise(
        (_, reject) => setTimeout(() => reject(new Error("Timeout")), 3e3)
      );
      const response = await Promise.race([apiCall, timeoutPromise]);
      const text = response.text;
      if (!text) {
        throw new Error("Empty response from Gemini");
      }
      const result = JSON.parse(text.trim());
      return {
        isValid: typeof result.isValid === "boolean" ? result.isValid : true,
        reason: result.reason || "Mensagem identificada como spam ou suspeita de publicidade."
      };
    } catch (err) {
      console.error(`Gemini API validation attempt ${attempt} failed:`, err.message);
      const isTransient = err.message.includes("503") || err.message.includes("Service Unavailable") || err.message.includes("Timeout");
      if (attempt === maxRetries || !isTransient) {
        break;
      }
      await new Promise((resolve) => setTimeout(resolve, delay));
      delay *= 2;
    }
  }
  console.warn("Validation failed or timed out. Falling back to pass-through (isValid: true).");
  return { isValid: true };
}
async function startServer() {
  const app = (0, import_express.default)();
  let port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
  app.use(import_express.default.json());
  app.post("/api/validate", async (req, res) => {
    try {
      const { firstName, lastName, message, phone } = req.body;
      if (!firstName || !lastName || !message) {
        return res.status(400).json({ isValid: false, reason: "Campos obrigat\xF3rios ausentes." });
      }
      const result = await validateWithGemini({ firstName, lastName, message, phone });
      return res.json(result);
    } catch (error) {
      console.error("Error in /api/validate endpoint:", error);
      return res.json({ isValid: true });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  function listen(p) {
    const server = app.listen(p, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${p}`);
    });
    server.on("error", (err) => {
      if (err.code === "EADDRINUSE") {
        console.warn(`Port ${p} is already in use. Trying port ${p + 1}...`);
        listen(p + 1);
      } else {
        console.error("Server error:", err);
      }
    });
  }
  listen(port);
}
startServer();
//# sourceMappingURL=server.cjs.map
